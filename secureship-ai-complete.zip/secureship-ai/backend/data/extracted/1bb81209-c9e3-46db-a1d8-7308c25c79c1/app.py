# Move secrets into environment variables or Secret Manager:
import os

# INSTEAD OF: API_KEY = 'hardcoded_value'
API_KEY = os.getenv('API_KEY')
if not API_KEY:
    raise RuntimeError('Missing required API_KEY environment variable.')