---
name: Sahay Modern State
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#525657'
  on-tertiary: '#ffffff'
  tertiary-container: '#6b6e70'
  on-tertiary-container: '#eff1f3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  success-green: '#059669'
  warning-amber: '#D97706'
  error-red: '#DC2626'
  info-sky: '#0EA5E9'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-max: 1280px
  gutter-desktop: 24px
  margin-desktop: 48px
  gutter-mobile: 16px
  margin-mobile: 20px
---

## Brand & Style

This design system is built on the principles of **Institutional Modernism**. It aims to transform the traditional government portal experience into a streamlined, citizen-centric platform that radiates efficiency, transparency, and accessibility. 

The style is **Corporate / Modern**, leaning heavily into high-clarity layouts and functional aesthetics. It avoids unnecessary decorative elements in favor of purposeful structure. The emotional response should be one of "Ease and Assurance"—minimizing the cognitive load often associated with administrative tasks through generous white space and a highly organized visual hierarchy. The design system leverages subtle depth and a refined blue palette to maintain a connection to authority while feeling technologically advanced and approachable for all demographics.

## Colors

The color palette is anchored by the primary brand blue, which represents stability and trust. This is balanced against a deep slate secondary color used for high-contrast text and structural navigation. 

- **Primary Blue (#2563EB):** Reserved for primary actions, active states, and brand identifiers.
- **Secondary Slate (#0F172A):** Used for typography and dark-mode headers to provide a grounded, authoritative feel.
- **Functional Accents:** Success Green and Warning Amber are utilized strictly for status communication (e.g., application approved, pending verification).
- **Surface Neutrals:** A range of cool grays (Slate 50 to 900) provides the foundation for the UI layers, ensuring high legibility and a clean aesthetic.

## Typography

This design system uses a dual-font strategy to balance character with utility. **Plus Jakarta Sans** is used for headlines to provide a friendly, modern, and welcoming atmosphere. **Inter** is the workhorse for body text and UI labels, chosen for its exceptional legibility at small sizes and its neutral, systematic feel.

For accessibility, the minimum font size for primary content is 16px. Line heights are kept generous (1.5x for body text) to assist users with varying visual abilities. Uppercase labeling is used sparingly for category headers and utility labels to create a distinct visual break from prose.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. On desktop, content is contained within a 1280px central track using a 12-column grid. On mobile devices, the system transitions to a single-column fluid layout with 20px side margins.

A strict 4px (base) and 8px (standard) spacing scale is used to define all gutters, padding, and margins. This ensures mathematical harmony across the interface. 
- **Large Sections:** 64px–80px vertical spacing.
- **Component Internals:** 12px–24px padding.
- **Card Grit:** 24px gutters between cards on desktop, 16px on mobile.

## Elevation & Depth

The design system utilizes **Tonal Layers** combined with **Ambient Shadows** to create a sense of organized hierarchy. 

The background layer is typically the lightest neutral (#F8FAFC). Primary content is housed in white (#FFFFFF) containers that feature a very subtle 1px border (#E2E8F0) and a soft, diffused shadow. Shadows are tinted with the secondary slate color at 4%–6% opacity to prevent them from looking "dirty."

1.  **Level 0 (Flat):** Background surfaces.
2.  **Level 1 (Low):** Standard cards and interactive fields. Subtle shadow: 0px 2px 4px rgba(15, 23, 42, 0.05).
3.  **Level 2 (High):** Hovered states, dropdowns, and modals. Pronounced shadow: 0px 10px 15px -3px rgba(15, 23, 42, 0.1).

## Shapes

The shape language is **Rounded**, conveying friendliness while maintaining a professional structure. 

A 0.5rem (8px) corner radius is the standard for cards, input fields, and standard buttons. This radius is large enough to feel modern and "soft" but small enough to maintain a sense of precision. Icons and small badges use a fully circular (pill) shape to distinguish them as secondary decorative or status elements.

## Components

### Buttons
Primary buttons use a solid #2563EB fill with white text. Secondary buttons use a white background with a 1px slate-200 border. All buttons have a height of 44px (mobile friendly) and 8px rounded corners.

### Cards
Cards are the primary container for schemes. They feature a white background, a 1px border (#E2E8F0), and a Level 1 shadow. Header sections within cards should have a subtle top-border accent in the primary blue.

### Input Fields
Inputs use a white fill with a 1px border that thickens and turns blue on focus. Labels are always positioned above the field for clarity. Error states must include both a red border (#DC2626) and an assistive icon/text for accessibility.

### Chips & Badges
Badges (e.g., for "New Scheme" or "Active") use a low-saturation background with a high-saturation text of the same hue (e.g., Light Green BG / Dark Green Text) to ensure legibility without being visually overwhelming.

### Progress Steppers
Crucial for government forms, steppers must be prominent. Use a vertical layout for mobile and horizontal for desktop, utilizing the primary blue for completed stages and a neutral gray for upcoming ones.