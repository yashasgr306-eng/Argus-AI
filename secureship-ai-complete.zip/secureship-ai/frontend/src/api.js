const API_BASE = '/api';

export async function checkHealth() {
  const res = await fetch('/health');
  if (!res.ok) throw new Error('Backend health check failed');
  return res.json();
}

export async function getAgentStatus() {
  const res = await fetch(`${API_BASE}/agent/status`);
  if (!res.ok) throw new Error('Failed to fetch agent status');
  return res.json();
}

export async function uploadAndScan(file) {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${API_BASE}/scan`, {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Upload scan failed' }));
    throw new Error(err.detail || 'Scan failed');
  }
  return res.json();
}

export async function scanDemoSample(sampleType) {
  const res = await fetch(`${API_BASE}/scans/sample/${sampleType}`, {
    method: 'POST',
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Sample scan failed' }));
    throw new Error(err.detail || 'Failed to scan sample');
  }
  return res.json();
}

export async function getScan(scanId) {
  const res = await fetch(`${API_BASE}/scan/${scanId}`);
  if (!res.ok) throw new Error('Scan not found');
  return res.json();
}

export async function reviewFindingWithAgent(findingData) {
  const res = await fetch(`${API_BASE}/agent/review`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      finding_id: findingData.id,
      file_path: findingData.file_path,
      line_number: findingData.line_number,
      rule_id: findingData.rule_id,
      scanner_name: findingData.scanner_name,
      severity: findingData.severity,
      message: findingData.message,
      code_snippet: findingData.code_snippet
    })
  });
  if (!res.ok) throw new Error('Agent review failed');
  return res.json();
}

export async function rescanProject(scanId, remediatedFiles = {}) {
  const res = await fetch(`${API_BASE}/scan/${scanId}/rescan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ remediated_files: remediatedFiles })
  });
  if (!res.ok) throw new Error('Rescan failed');
  return res.json();
}

export async function getResearchMetrics() {
  const res = await fetch(`${API_BASE}/research/metrics`);
  if (!res.ok) throw new Error('Failed to fetch benchmark metrics');
  return res.json();
}

export async function runBenchmarkEvaluation() {
  const res = await fetch(`${API_BASE}/research/run-benchmark`, {
    method: 'POST',
  });
  if (!res.ok) throw new Error('Benchmark run failed');
  return res.json();
}
