import React from 'react';
import { Shield, Sparkles, Database, FileText, Cpu, Download } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, agentStatus }) {
  return (
    <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40">
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '4.5rem' }}>
        
        {/* Brand */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
          <div style={{
            background: 'linear-gradient(135deg, #38bdf8, #6366f1)',
            padding: '0.6rem',
            borderRadius: '0.75rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 20px rgba(56, 189, 248, 0.4)'
          }}>
            <Shield size={24} color="#ffffff" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ fontSize: '1.25rem', fontWeight: '800', letterSpacing: '-0.025em', color: '#f8fafc' }}>
                SecureShip <span style={{ color: '#38bdf8' }}>AI</span>
              </span>
              <span className="badge badge-scanner" style={{ fontSize: '0.65rem', padding: '0.15rem 0.5rem' }}>
                Hackathon MVP
              </span>
            </div>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              Deterministic Scanners + IBM Security Review Agent
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <button
            onClick={() => setActiveTab('auditor')}
            className={`btn ${activeTab === 'auditor' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
          >
            <Shield size={16} />
            Security Auditor
          </button>

          <button
            onClick={() => setActiveTab('research')}
            className={`btn ${activeTab === 'research' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
          >
            <Database size={16} />
            Research Benchmark (40 Samples)
          </button>

          <button
            onClick={() => setActiveTab('demo')}
            className={`btn ${activeTab === 'demo' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
          >
            <FileText size={16} />
            3-Min Demo Script
          </button>

          <a
            href="/api/download-project"
            download="secureship-ai-complete.zip"
            className="btn btn-secondary"
            style={{ padding: '0.5rem 1rem', fontSize: '0.85rem', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
            title="Download complete project ZIP"
          >
            <Download size={16} color="#38bdf8" />
            Download ZIP
          </a>
        </nav>

        {/* IBM Agent Status */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            padding: '0.4rem 0.85rem',
            borderRadius: '9999px',
            background: 'rgba(30, 41, 59, 0.8)',
            border: '1px solid rgba(148, 163, 184, 0.2)',
            fontSize: '0.75rem'
          }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: agentStatus?.live_ibm_configured ? '#10b981' : '#38bdf8',
              boxShadow: `0 0 8px ${agentStatus?.live_ibm_configured ? '#10b981' : '#38bdf8'}`
            }} />
            <Cpu size={14} color="#94a3b8" />
            <span style={{ color: '#cbd5e1', fontWeight: 600 }}>
              {agentStatus?.live_ibm_configured ? 'IBM watsonx Active' : 'IBM Granite Review Agent'}
            </span>
          </div>
        </div>

      </div>
    </header>
  );
}
