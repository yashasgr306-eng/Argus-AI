import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import UploadZone from './components/UploadZone';
import SecurityScoreCard from './components/SecurityScoreCard';
import FindingsTable from './components/FindingsTable';
import FindingDetailModal from './components/FindingDetailModal';
import RescanComparison from './components/RescanComparison';
import ResearchBenchmarkView from './components/ResearchBenchmarkView';
import DemoScriptView from './components/DemoScriptView';
import { uploadAndScan, scanDemoSample, rescanProject, getAgentStatus } from './api';

export default function App() {
  const [activeTab, setActiveTab] = useState('auditor');
  const [agentStatus, setAgentStatus] = useState(null);
  
  const [currentScan, setCurrentScan] = useState(null);
  const [previousScan, setPreviousScan] = useState(null);
  const [showRescanDiff, setShowRescanDiff] = useState(false);
  
  const [selectedFinding, setSelectedFinding] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    // Check IBM Agent status on load
    getAgentStatus().then(setAgentStatus).catch(console.error);
    
    // Auto-load vulnerable sample on initial launch for immediate visualization
    handleSampleLoad('vulnerable');
  }, []);

  const handleFileUpload = async (file) => {
    setScanning(true);
    setErrorMsg('');
    setShowRescanDiff(false);
    try {
      const scanData = await uploadAndScan(file);
      setPreviousScan(null);
      setCurrentScan(scanData);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setScanning(false);
    }
  };

  const handleSampleLoad = async (sampleType) => {
    setScanning(true);
    setErrorMsg('');
    setShowRescanDiff(false);
    try {
      const scanData = await scanDemoSample(sampleType);
      setPreviousScan(null);
      setCurrentScan(scanData);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setScanning(false);
    }
  };

  const handleRescan = async (finding, fixCode) => {
    if (!currentScan) return;
    setScanning(true);
    try {
      // Trigger rescan with proposed fix
      const rescanData = await rescanProject(currentScan.id, {
        [finding.file_path]: fixCode
      });
      setPreviousScan(currentScan);
      setCurrentScan(rescanData);
      setShowRescanDiff(true);
    } catch (err) {
      setErrorMsg(`Rescan verification error: ${err.message}`);
    } finally {
      setScanning(false);
    }
  };

  const handleUpdateFindingReview = (findingId, reviewData) => {
    if (!currentScan) return;
    setCurrentScan(prev => ({
      ...prev,
      findings: prev.findings.map(f => f.id === findingId ? { ...f, review: reviewData } : f)
    }));
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      
      {/* Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        agentStatus={agentStatus}
      />

      {/* Main Content Area */}
      <main className="container" style={{ flex: 1, padding: '2rem 1.5rem' }}>
        
        {/* Error Notification */}
        {errorMsg && (
          <div style={{
            background: 'rgba(239, 68, 68, 0.15)',
            border: '1px solid rgba(239, 68, 68, 0.4)',
            color: '#fca5a5',
            padding: '1rem',
            borderRadius: '0.5rem',
            marginBottom: '1.5rem',
            fontSize: '0.875rem'
          }}>
            <strong>Error: </strong> {errorMsg}
          </div>
        )}

        {/* Tab 1: Security Auditor */}
        {activeTab === 'auditor' && (
          <>
            <UploadZone
              onFileUpload={handleFileUpload}
              onSampleLoad={handleSampleLoad}
              scanning={scanning}
            />

            {/* Before-and-After Rescan Comparison */}
            {showRescanDiff && previousScan && currentScan && (
              <RescanComparison
                originalScan={previousScan}
                rescanScan={currentScan}
                onDismiss={() => setShowRescanDiff(false)}
              />
            )}

            {/* Security Score Breakdown */}
            {currentScan && (
              <SecurityScoreCard scan={currentScan} />
            )}

            {/* Findings Table */}
            {currentScan && (
              <FindingsTable
                findings={currentScan.findings || []}
                onSelectFinding={setSelectedFinding}
                selectedFindingId={selectedFinding?.id}
              />
            )}
          </>
        )}

        {/* Tab 2: Research Benchmark */}
        {activeTab === 'research' && (
          <ResearchBenchmarkView />
        )}

        {/* Tab 3: 3-Minute Demo Script */}
        {activeTab === 'demo' && (
          <DemoScriptView
            onTriggerStep={(stepType) => {
              setActiveTab('auditor');
              handleSampleLoad(stepType);
            }}
          />
        )}

        {/* Finding Detail / IBM Review Modal */}
        {selectedFinding && (
          <FindingDetailModal
            finding={selectedFinding}
            onClose={() => setSelectedFinding(null)}
            onRescan={handleRescan}
            onUpdateFindingReview={handleUpdateFindingReview}
          />
        )}

      </main>

      {/* Footer */}
      <footer style={{ borderTop: '1px solid #1e293b', padding: '1.5rem 0', background: '#090d16', textAlign: 'center', fontSize: '0.75rem', color: '#64748b' }}>
        <div className="container">
          <p>SecureShip AI · IBM watsonx Orchestrate / Granite Security Review Agent · Built for Hackathon Track R1</p>
        </div>
      </footer>

    </div>
  );
}
